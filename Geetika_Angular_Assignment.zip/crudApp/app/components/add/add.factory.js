/**
 * Created by knoldus on 24/2/16.
 */

angular.module('crudApp').factory('addFactory',function($http){

   alert("In add factory");
   return $http.post("reactive-app.herokuapp.com/create",emp);

}


);