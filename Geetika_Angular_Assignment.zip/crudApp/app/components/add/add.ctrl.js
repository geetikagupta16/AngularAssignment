/**
 * Created by knoldus on 24/2/16.
 */


angular.module('crudApp').controller('addCtrl',function($scope,$location,$http){

   alert("In Add controller");

    $scope.goToAdd=function(){

alert("In ADD Controller inside gotoadd function");
   $location.path('/add');

    }
    $scope.addEmployee=function(){

        alert(" Inside Add EMployee function");
        $scope.emp={
            "name":$scope.empName,
            "email":$scope.empEmail,
            "dob":$scope.empDob,
            "companyName":$scope.empCompanyname,
            "id":$scope.empId
        };

        alert(JSON.stringify($scope.emp));
        $http.post("reactive-app.herokuapp.com/create/",$scope.emp);

        // var x=addFactory
        alert("after add factory call")
       /* x.then(function(){
            alert(emp);
            $location.path('/list');
        })

        addFactory.createEmployee(emp).success(alert("data saved"));
        $state.go(list);

*/
        $location.path('/list')
    }


    });
