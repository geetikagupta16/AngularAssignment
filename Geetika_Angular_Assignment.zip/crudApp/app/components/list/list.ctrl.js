/**
 * Created by knoldus on 24/2/16.
 */


angular.module('crudApp').controller('listCtrl',function($scope,listFactory){

    alert("In list controller");

    var x=listFactory;
    x.then(function(response){

      $scope.employee=response.data;

    });

});