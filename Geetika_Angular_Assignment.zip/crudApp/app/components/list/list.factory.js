/**
 * Created by knoldus on 24/2/16.
 */


angular.module('crudApp').factory('listFactory',function($http){

    alert("In list factory");


    return $http.get("http://reactive-app.herokuapp.com/getAll");


    }
);