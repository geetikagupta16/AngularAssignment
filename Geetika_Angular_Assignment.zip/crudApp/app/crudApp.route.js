
    angular.module('crudApp').config(function($stateProvider,$urlRouterProvider){

        $urlRouterProvider.otherwise('/list');

        $stateProvider
            .state('list',{
                url:'/list',
                templateUrl:'/crudApp/app/components/list/list.html',
                controller:'listCtrl'

            })
            .state('add',{

                url:'/add',
                templateUrl:'/crudApp/app/components/add/add.html',
                controller:'addCtrl'

            })



    });