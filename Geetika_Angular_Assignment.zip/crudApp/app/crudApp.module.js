
    "use strict";
    angular.module('crudApp',[
        'ui.router'
    ]);
